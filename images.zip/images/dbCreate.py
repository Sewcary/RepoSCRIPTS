# -*- coding: utf-8 -*-
"""
Created on Mon Apr 15 13:30:02 2024


"""

import sqlite3

# Connexion à la base de données SQLite
conn = sqlite3.connect('images_database.db')
c = conn.cursor()

# Créer une table pour stocker les images
c.execute('''
CREATE TABLE IF NOT EXISTS images (
    id INTEGER PRIMARY KEY,
    image_name TEXT,
    image_data BLOB
)
''')
conn.commit()

